import java.util.Locale;
import java.util.Scanner;

public class ContaTerminal {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in).useLocale(Locale.US);
        
        System.out.println("\n Por favor, digite o número da agencia");
        String agencia = scanner.next();

        System.out.println("\n Por obséquio, digite seu nome");
        String nome = scanner.next();

        System.out.println("\n Por gentileza, digite o número da sua conta");
        int nconta = scanner.nextInt();
        
        System.out.println("\n Por cortesia, digite o saldo presente na conta");
        double saldo = scanner.nextDouble();

        System.out.println("\nOlá " + nome + "\nObrigado por criar uma conta em nosso banco, sua agência é: " + agencia  + ",\nconta número " + nconta  +" e seu saldo R$:" + saldo + " já está disponível para saque.");
        

    }
}